package sc.demo.androidcarmera;

import sc.tool.carmera.CarmeraActivity;
import sc.tool.carmera.CarmeraActivity.CarmeraCallBack;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity2 extends Activity
{
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
	
	public void TakePhoto(View view)
	{
		// 拍照
		CarmeraActivity.TakePhoto(this, new CarmeraCallBack()
		{
			@Override
			public void Success(String filePath)
			{
				Toast.makeText(MainActivity2.this, "拍照完成" + "\n" + filePath, Toast.LENGTH_SHORT).show();
			}
		});
	}
	
	public void TakeVedio(View view)
	{
		// 录像
		CarmeraActivity.TakeVedio(this, new CarmeraCallBack()
		{
			@Override
			public void Success(String filePath)
			{
				Toast.makeText(MainActivity2.this, "录像完成" + "\n" + filePath, Toast.LENGTH_SHORT).show();
			}
		});
	}
}
